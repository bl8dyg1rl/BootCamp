PI = 3.14

def area_triangulo(altura, base):
    area_t = (base*altura)/2     
    print("El área del triangulo es: ",area_t)
       
def area_circulo(radio):
    area_c = PI*(radio**2)
    print("El área del círculo es: ",area_c)

area_triangulo(20, 40)
area_circulo(3)