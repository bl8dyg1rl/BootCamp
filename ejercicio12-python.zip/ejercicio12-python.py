def bisiesto(año):
    if año % 4 == 0:
        print("Es bisiesto")
    elif año % 100 == 0:
        print("Es bisiesto")
    elif año % 400 == 0:
        print("Es bisiesto")
    else:
        print("No es bisiesto")

bisiesto(2012)