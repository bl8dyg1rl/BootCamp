numero_inicial = 2
numero_final = 8

lista = []

for i in range(numero_inicial, numero_final):
    if i%2 != 0:
        lista.append(i)
print(lista)