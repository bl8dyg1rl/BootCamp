lista = []

for i in range(1,101):
    lista.append(i)
lista.reverse()    

for j in lista:
    print(j)
    