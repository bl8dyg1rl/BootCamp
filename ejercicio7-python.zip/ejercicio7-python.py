edad = int(input("Ingrese su edad: "))

if edad < 18:
    print("Eres menor de edad.")

else:
    print("Eres mayor de edad.")
