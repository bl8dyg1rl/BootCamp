public class Main{

    public static void main(String[] args) {
        // Artibutos del cliente.
        Cliente cliente = new Cliente();
        System.out.println("- Cliente: ");
        cliente.setEdad(24);
        cliente.setNombre("Lisa");
        cliente.setTelefono(123456);
        cliente.setCredito(5000000);

        System.out.println("Su edad es: " + cliente.getEdad());
        System.out.println("Su nombre es: " + cliente.getNombre());
        System.out.println("Su telefono es: " + cliente.getTelefono());
        System.out.println("Su credito es: " + cliente.getCredito());

        // Atributos del trabajador.
        Trabajador trabajador = new Trabajador();
        System.out.println("- Trabajador: ");
        trabajador.setEdad(26);
        trabajador.setNombre("Jisoo");
        trabajador.setTelefono(6789);
        trabajador.setSalario(2000000);

        System.out.println("Su edad es: " + trabajador.getEdad());
        System.out.println("Su nombre es: " + trabajador.getNombre());
        System.out.println("Su telefono es: " + trabajador.getTelefono());
        System.out.println("Su salario es: " + trabajador.getSalario());
    }
}
class Persona{
    int edad;
    String nombre;
    int telefono;
    public int getEdad(){
        return this.edad;
    }
    public void setEdad(int edad){
        this.edad = edad;
    }
    public String getNombre(){
        return this.nombre;
    }
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    public int getTelefono(){
        return this.telefono;
    }
    public void setTelefono(int telefono){
        this.telefono = telefono;
    }
}
class Cliente extends Persona{
    int credito;
    public int getCredito(){
        return this.credito;
    }
    public void setCredito(int credito){
        this.credito = credito;
    }
}
class Trabajador extends Persona{
    int salario;
    public int getSalario(){
        return this.salario;
    }
    public void setSalario(int salario){
        this.salario = salario;
    }
}