public class Main{
    public static void main(String[] args) {
        int numeroIf = 3;

        if (numeroIf < 0){
            System.out.println("El número es negativo.");
        } else if (numeroIf > 0) {
            System.out.println("El número es positivo.");
        } else {
            System.out.println("El número es 0.");
        }

        int numeroWhile = 1;

        while (numeroWhile < 3){
            System.out.println(numeroWhile);
            numeroWhile = numeroWhile + 1;
        }

        int numeroDoWhile = 4;

        do {
            System.out.println(numeroDoWhile);
            numeroDoWhile = numeroDoWhile + 1;
        } while (numeroDoWhile < 3);

        for (int numeroFor = 0; numeroFor <= 3; numeroFor = numeroFor + 1){
            System.out.println(numeroFor);
        }

        String estacion = "invierno";

        switch (estacion){
            case "verano":
                System.out.println("Es verano.");
                break;
            case "invierno":
                System.out.println("Es invierno.");
                break;
            case "otoño":
                System.out.println("Es otoño.");
                break;
            case "primavera":
                System.out.println("Es primavera.");
                break;
            default:
                System.out.println("No es una estación.");
        }
    }
}