public class Main {
    public static void main(String[] args) {
        suma(1, 2, 3);
        Coche miCoche = new Coche();
        miCoche.AñadirPuerta();
        System.out.println("El numero de puertas del coche es: " + miCoche.puertas);
    }

    public static void suma(int a, int b, int c) {
        int resultado;
        resultado = a + b + c;

        System.out.println("El resultado de la suma es: " + resultado);
    }
}
class Coche {
    public int puertas = 1;

    public void AñadirPuerta(){
        this.puertas++;

    }


}